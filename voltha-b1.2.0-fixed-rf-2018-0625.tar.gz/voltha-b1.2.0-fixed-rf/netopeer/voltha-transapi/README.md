Voltha TransAPI
---------------

### Introduction

The Voltha TransAPI library adds support to interact with Voltha through the Netopeer NETCONF 
server.

This library can be used as a template for implementing a TransAPI for your own YANG model(s).

### TODO(s)

* Only a few methods have been implemented as it is purely for demonstration.







