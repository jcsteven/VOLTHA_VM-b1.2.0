## M20 - MIB Download and Upload

### Test Objective

* Purpose of this test is to verify OMCI MIB is downloaded from OLT to ONU and vice versa as part of ONU ranging process

### Test Configuration
* Test Setup as shown in Section – 7

### Test Procedure
* Activate the Maple OLT and ONU using VOLTHA

### Pass / Fail Criteria
* Once the ONU ranges, OMCI MIB is downloaded from OLT to ONU and vice versa 

