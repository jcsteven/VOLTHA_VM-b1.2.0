import os
import sys
voltha_base = os.getenv("VOLTHA_BASE",".")
sys.path.append(voltha_base+'/ofagent/')
