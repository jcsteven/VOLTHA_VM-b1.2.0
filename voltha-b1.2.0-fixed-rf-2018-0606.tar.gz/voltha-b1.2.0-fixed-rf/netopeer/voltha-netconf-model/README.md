Voltha Netconf Model Translation Utility
----------------------------------------

### Introduction

This GoLang library is a utility used to translate from the Voltha C data model to the YANG data 
model.  This is simply to demonstrate how to provide an easy method to perform the translation to
YANG xml.

This library can be used as a template for your own YANG model(s).

### TODO(s)

* The user-facing API, i.e. the exported methods, need to be manually added.  Only a few commands 
have been completed as it is purely for demonstration.







