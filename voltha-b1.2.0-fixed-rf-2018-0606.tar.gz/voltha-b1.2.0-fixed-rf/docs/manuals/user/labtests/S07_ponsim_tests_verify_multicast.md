# S7 - Verify Multicast Access
