# M4 - Verify DHCP Lookup
