## M13 - Spirent - Verify Re-Write C-VID Upstream

### Test Objective

* The purpose of this test is to verify ONU can re-write Priority tagged frames (VLAN ID 0) with single c-VID in upstream to wards OLT

### Test Configuration
* Test Setup as shown in Section – 7
* Maple OLT and ONU is activated using VOLTHA
* Provision HSIA/unicast service on the OLT and connected ONU from VOLTHA

### Test Procedure

### Pass/Fail Criteria
