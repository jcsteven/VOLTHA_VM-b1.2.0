## T14 - Spirent - Verify Re-Write C-VID Downstream

### Test Objective
* The Purpose of this test is to verify ONU can re-write single C-VID frames as priority tagges frames in downstream towards RG

### Test Configuration
* Test Setup as shown in Section – 7
* Tibit OLT and ONU is activated using VOLTHA
* Provision HSIA/unicast service on the OLT and connected ONU from VOLTHA

### Test Procedure

### Pass/Fail Criteria
