# M6 - Verify IGMP Handling
