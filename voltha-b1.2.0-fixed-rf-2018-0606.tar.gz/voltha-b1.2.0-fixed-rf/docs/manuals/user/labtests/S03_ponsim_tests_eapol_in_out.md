## S3 - Test EAPOL In/Out Forwarding with OLT-OFTEST

### Test Objective

### Test Configuration

### Test Procedure

### Pass/Fail Criteria
