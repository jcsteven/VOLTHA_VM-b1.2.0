## P3 - Voltha's Partial Readiness for Scale-out
