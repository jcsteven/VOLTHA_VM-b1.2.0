#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys,os,subprocess,time,socket,re

#print sys.argv[0], len(sys.argv)
ENVOY_IP="localhost"
KARAF_IP="localhost"
ENVOY_PORT=8882
KARAF_PORT=8181
KARAF_USER="karaf"
KARAF_PASSWORD="karaf"
VOLTHA_BASE_URL="http://" + ENVOY_IP + ":" + str(ENVOY_PORT) + "/api/v1"
ONOS_BASE_URL="http://" + KARAF_IP + ":" + str(KARAF_PORT) + "/onos/v1"
HTTP_HEADER="-H 'Content-Type: application/json'"
LOGICAL_PORT="21"
#COMMAND=['ds','up','down','restart','all','add','delete','enable','status','config','flows','ports','add-sub','aaa','dhcp','uplink','logs',"reboot","go"]
#COMMAND=['ds','up','down','restart','all','add','delete','enable','status','config','flows','ports','add-sub','uplink','logs',"reboot"]
COMMAND=['ds','up','down','restart','all','add','enable','status','config','flows','ports','add-sub','uplink','logs',"reboot"]
'''
CMD_USAGE=COMMAND[0] + "\t: Show Dockers status\n" + \
COMMAND[1] + "\t: Start Dockers\n" + \
COMMAND[2] + "\t: Stop Dockers\n" + \
COMMAND[3] + "\t: Restart Dockers\n" + \
COMMAND[4] + "\t: All configurations to be perform\n" + \
COMMAND[5] + "\t: Add OLT connection\n" + \
COMMAND[6] + "\t: Delete OLT connection\n" + \
COMMAND[7] + "\t: Enable CLI and OLT initial chips\n" + \
COMMAND[8] + "\t: Show OLT/ONU status\n" + \
COMMAND[9] + "\t: Configure ONU network model\n" + \
COMMAND[10] + "\t: Show ONOS flows\n" + \
COMMAND[11] + "\t: Show ONOS ports\n" + \
COMMAND[12] + "\t: Add ONU subscriber\n" + \
COMMAND[13] + "\t: Add AAA ONOS Configurations\n" + \
COMMAND[14] + "\t: Add DHCP ONOS Configurations\n" + \
COMMAND[15] + "\t: Add OLT up link network\n" + \
COMMAND[16] + "\t: Show docker messages\n" + \
COMMAND[17] + "\t: Reboot OLT/ONU\n" + \
COMMAND[18] + "\t: One-time-fly"
'''
CMD_USAGE=COMMAND[0] + "\t: Show Dockers status\n" + \
COMMAND[1] + "\t: Start Dockers\n" + \
COMMAND[2] + "\t: Stop Dockers\n" + \
COMMAND[3] + "\t: Restart Dockers\n" + \
COMMAND[4] + "\t: All configurations to be perform\n" + \
COMMAND[5] + "\t: Add OLT connection\n" + \
COMMAND[6] + "\t: Enable CLI and OLT initial chips\n" + \
COMMAND[7] + "\t: Show OLT/ONU status\n" + \
COMMAND[8] + "\t: Configure ONU network model\n" + \
COMMAND[9] + "\t: Show ONOS flows\n" + \
COMMAND[10] + "\t: Show ONOS ports\n" + \
COMMAND[11] + "\t: Add ONU subscriber\n" + \
COMMAND[12] + "\t: Add OLT up link network\n" + \
COMMAND[13] + "\t: Show docker messages\n" + \
COMMAND[14] + "\t: Reboot OLT/ONU\n" 

max_delay_time=300
time_tick=1
method=["enable","config"]
unit_type=["OLT","ONU"]
#OUTPUT=" -o /dev/null "
OUTPUT=""
hidden_log=""
if OUTPUT != "":
    hidden_log=" > /dev/null 2>&1 "

try:  
    voltha_env=os.environ['VOLTHA_BASE']
except KeyError: 
    print "Please set the environment variable. ex: source env.sh"
    sys.exit(1)

if len(sys.argv) <= 1 or not sys.argv[1] in COMMAND:
    print "Usage: " + sys.argv[0] + " " + "/".join(COMMAND) + "\n" + CMD_USAGE
    sys.exit()

def detect_port(ip,port):
    sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    return sock.connect_ex((ip,port))

def validate_ip(ip_str):
    reg = r"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-4])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-4])$"
    if re.match(reg, ip_str):
        return True
    else:
        return False

def validate_mac(mac):
    rules='([a-fA-F0-9]{2}[:}\-]?){6}'
    result=re.compile(rules).search(mac)
    if result:
        #print mac[a.start(): a.end()]
        return True
    return False

def get_olt_id(conditions):
    have_olt_id=0
    for olts in range(0,10):
        admin_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].admin_state'], shell=True)
        if admin_status.rstrip("\n") != "null":
            if conditions == 1:
                oper_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].oper_status'], shell=True)
                check_flag = admin_status.rstrip("\n") == "ENABLED" and oper_status.rstrip("\n") == "ACTIVE"
            else:
                check_flag = admin_status.rstrip("\n") == "PREPROVISIONED"

            if check_flag == True:
               olt_id = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].id'], shell=True)
               olt_type = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].type'], shell=True)
               olt_host = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].host_and_port'], shell=True)
               print "ID=" + olt_id.rstrip("\n") + " Type=" + olt_type.rstrip("\n") + " Host_and_Port=" + olt_host.rstrip("\n")
               have_olt_id=1
    return have_olt_id


def get_waiting_olt_onu(item):
    #for item in [0,1]:
    '''
    if method[item] == "enable":
        olt_id = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(item) + '].id'], shell=True)
        os.system(sys.argv[0] + " " + method[item] + " " + olt_id.rstrip("\n"))
    else:
        os.system(sys.argv[0] + " " + method[item])
    '''
    print
    delay_time=time_tick
    while delay_time < max_delay_time:
        print("%s %s, waiting for %d seconds" % (method[item],unit_type[item],delay_time))
        time.sleep(time_tick)
        delay_time += time_tick
        oper_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r ".items[' + str(item) + '].oper_status"'], shell=True)
        if oper_status.rstrip("\n") == "ACTIVE":
            break
    if delay_time >= max_delay_time:
        print ("Over time for %s %s, quit!!" % (method[item],unit_type[item]))
        return False
    return True

if not sys.argv[1] in ["ds","up","down","restart","logs"]:
    if detect_port(ENVOY_IP,int(ENVOY_PORT)) != 0:
        print "The Envoy service does not run now"
        print "Usage: " + sys.argv[0] + " restart"
        sys.exit()

if sys.argv[1] == "ds":
    os.system("docker-compose -f compose/docker-compose-system-test.yml ps")
    os.system("docker-compose -f compose/docker-compose-auth-test.yml ps")
elif sys.argv[1] == "up":
    os.system("docker-compose -f compose/docker-compose-system-test.yml up -d")
    time.sleep(10)
    os.system("docker-compose -f compose/docker-compose-auth-test.yml up -d onos freeradius")
elif sys.argv[1] == "down":
    os.system("docker-compose -f compose/docker-compose-system-test.yml down")
    os.system("docker-compose -f compose/docker-compose-auth-test.yml down")
elif sys.argv[1] == "logs":
    os.system("docker-compose -f compose/docker-compose-system-test.yml logs")
    os.system("docker-compose -f compose/docker-compose-auth-test.yml logs")
elif sys.argv[1] == "restart":
    os.system(sys.argv[0] + " down")
    time.sleep(10)
    os.system(sys.argv[0] + " up")
elif sys.argv[1] == "add":
    if len(sys.argv) != 3:
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <host:port>"
        sys.exit()

    if not validate_ip(sys.argv[2].split(':',1)[0]):
        print "Please check IP address"
        sys.exit()

    port_state=detect_port(sys.argv[2].split(':',1)[0],int(sys.argv[2].split(':',1)[1]))
    if port_state == 0:
        os.system("curl " + OUTPUT + HTTP_HEADER + " -s -X POST -d '{\"type\": \"asfvolt16_olt\", \
                \"host_and_port\": \"" + sys.argv[2] + "\"}' " + VOLTHA_BASE_URL + "/devices" + " | jq -r")
        
        time.sleep(2)
        os.system(sys.argv[0] + " status")
    else:
        print "No running vOLTHA adapter on OLT!!)"
        sys.exit()
elif sys.argv[1] == "enable":
    '''
    have_olt_id=0
    for olts in range(0,10):
        admin_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].admin_state'], shell=True)
        if admin_status.rstrip("\n") != "null":
            if admin_status.rstrip("\n") == "PREPROVISIONED":
                olt_id = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].id'], shell=True)
                olt_type = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].type'], shell=True)
                olt_host = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(olts) + '].host_and_port'], shell=True)
                print "ID=" + olt_id.rstrip("\n") + " Type=" + olt_type.rstrip("\n") + " Host_and_Port=" + olt_host.rstrip("\n")
                have_olt_id=1
    '''
    #if have_olt_id == 0:
    #if get_olt_id(0) == 0:
    #    print "Please check admin_status and oper_status"
    #    print "You should add preprovision OLT"
    #    sys.exit()
    #olt_id=raw_input("Please input OLT ID: ")

    if len(sys.argv) != 3:
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <OLT ID>"
        sys.exit()

    os.system("curl -s -X POST " + OUTPUT + VOLTHA_BASE_URL + "/devices/" + sys.argv[2].rstrip("\n") + "/enable")
    if get_waiting_olt_onu(0):
        print "Bring up OLT is done!!"
    else:
        sys.exit()

elif sys.argv[1] == "reboot":
    if len(sys.argv) != 3 or sys.argv[2] == "":
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <ID>"
        sys.exit()

    os.system("curl -s -X POST " + OUTPUT + VOLTHA_BASE_URL + "/devices/" + sys.argv[2].rstrip("\n") + "/reboot")
elif sys.argv[1] == "status":
    for item in [0,1]:
        admin_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r ".items[' + str(item) + '].admin_state"'], shell=True)
        oper_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r ".items[' + str(item) + '].oper_status"'], shell=True)
        print "===> " + unit_type[item] + " status <==="
        print "admin_status = " + admin_status.rstrip("\n")
        print "oper_status = " + oper_status.rstrip("\n")
        if admin_status.rstrip("\n") == "ENABLED" or admin_status.rstrip("\n") == "PREPROVISIONED":
            os.system("curl -s " + VOLTHA_BASE_URL + "/devices | jq -r '.items[" + str(item) + "]'")
elif sys.argv[1] == "delete":
    admin_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r ".items[0].admin_state"'], shell=True)
    if admin_status.rstrip("\n") == "ENABLED":
        id = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r ".items[0].id"'], shell=True)
        os.system("curl -X DELETE --header 'Accept: application/json' " +  VOLTHA_BASE_URL + "/v_enets/Enet%20UNI%201/delete")
        os.system("curl -X DELETE --header 'Accept: application/json' " +  VOLTHA_BASE_URL + "/ont_anis/ATT%20Golden%20User/delete")
        os.system("curl -X DELETE --header 'Accept: application/json' " +  VOLTHA_BASE_URL + "/v_ont_anis/ATT%20Golden%20User/delete")
        os.system("curl -X DELETE --header 'Accept: application/json' " +  VOLTHA_BASE_URL + "/devices/" + id.rstrip("\n") + "/channel_terminations/PON%20port/delete")
        os.system("curl -X DELETE --header 'Accept: application/json' " +  VOLTHA_BASE_URL + "/channel_pairs/PON%20port/delete")
        os.system("curl -X DELETE --header 'Accept: application/json' " +  VOLTHA_BASE_URL + "/channel_partitions/WTC/delete")
        os.system("curl -X DELETE --header 'Accept: application/json' " +  VOLTHA_BASE_URL + "/channel_groups/Manhattan/delete")
        '''
        os.system("curl " + HTTP_HEADER + " -X POST " +  VOLTHA_BASE_URL + "/v_enets/Enet%20UNI%201/delete") 
        os.system("curl " + HTTP_HEADER + " -X POST " +  VOLTHA_BASE_URL + "/ont_anis/ATT%20Golden%20User/delete")
        os.system("curl " + HTTP_HEADER + " -X POST " +  VOLTHA_BASE_URL + "/v_ont_anis/ATT%20Golden%20User/delete")
        os.system("curl " + HTTP_HEADER + " -X POST " +  VOLTHA_BASE_URL + "/devices/" + id.rstrip("\n") + "/channel_terminations/PON%20port/delete")
        os.system("curl " + HTTP_HEADER + " -X POST " +  VOLTHA_BASE_URL + "/channel_pairs/PON%20port/delete")
        os.system("curl " + HTTP_HEADER + " -X POST " +  VOLTHA_BASE_URL + "/channel_partitions/WTC/delete")
        os.system("curl " + HTTP_HEADER + " -X POST " +  VOLTHA_BASE_URL + "/channel_groups/Manhattan/delete")
        os.system("echo curl -S -X POST " + VOLTHA_BASE_URL + "/devices/" + id.rstrip("\n") + "/disable")
        os.system("echo curl -s -X DELETE " + VOLTHA_BASE_URL + "/devices/" + id.rstrip("\n") + "/delete")
        '''
    else:
        print "Please enable OLT first"
elif sys.argv[1] == "config":
    #if get_olt_id(1) == 1:
    #    olt_id=raw_input("Please input OLT ID: ")

    if len(sys.argv) != 4:
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <OLT ID> <ONU Serial Number>"
        sys.exit()

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"interface\": { \
    \"enabled\": true, \
    \"link_up_down_trap_enable\": \"TRAP_DISABLED\", \
    \"type\": \"channelgroup\", \
    \"name\": \"Manhattan\", \
    \"description\": \"Channel Group for Manhattan\" \
  }, \
  \"cg_index\": 1, \
  \"data\": { \
    \"polling_period\": 100, \
    \"system_id\": \"000000\", \
    \"raman_mitigation\": \"RAMAN_NONE\", \
  }, \
  \"name\": \"Manhattan\" \
}' " + VOLTHA_BASE_URL + "/channel_groups/Manhattan")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/channel_groups | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/channel_groups"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"interface\": { \
    \"name\": \"WTC\", \
    \"description\": \"Channel Partition for World Trace Center in Manhattan\", \
    \"type\": \"channelpartition\", \
    \"enabled\": true, \
    \"link_up_down_trap_enable\": \"TRAP_DISABLED\" \
  }, \
  \"data\": { \
    \"channelgroup_ref\": \"Manhattan\", \
    \"fec_downstream\": false, \
    \"closest_ont_distance\": 0, \
    \"differential_fiber_distance\": 20, \
    \"authentication_method\": \"SERIAL_NUMBER\", \
    \"multicast_aes_indicator\": false \
  }, \
  \"name\": \"WTC\" \
}' " + VOLTHA_BASE_URL + "/channel_partitions/WTC")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/channel_partitions | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/channel_partitions"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"interface\": { \
    \"name\": \"PON port\", \
    \"description\": \"Channel Pair for Freedom Tower in WTC\", \
    \"type\": \"channelpair\", \
    \"enabled\": true, \
    \"link_up_down_trap_enable\": \"TRAP_DISABLED\" \
  }, \
  \"data\": { \
    \"channelgroup_ref\": \"Manhattan\", \
    \"channelpartition_ref\": \"WTC\", \
    \"channelpair_type\": \"channelpair\", \
    \"channelpair_linerate\": \"down_10_up_10\", \
    \"gpon_ponid_interval\": 0, \
    \"gpon_ponid_odn_class\": \"CLASS_A\" \
  }, \
  \"name\": \"PON port\" \
}' " + VOLTHA_BASE_URL + "/channel_pairs/PON%20port")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/channel_pairs | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/channel_pairs"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"id\": \"ffff000000000000\", \
  \"name\": \"TDP 1\", \
  \"fixed_bandwidth\": \"100000\", \
  \"assured_bandwidth\": \"500000\", \
  \"maximum_bandwidth\": \"1000000\", \
  \"priority\": 1, \
  \"weight\": 1, \
  \"additional_bw_eligibility_indicator\": \"ADDITIONAL_BW_ELIGIBILITY_INDICATOR_NONE\" \
}' " + VOLTHA_BASE_URL + "/traffic_descriptor_profiles/TDP%201")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/traffic_descriptor_profiles | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/traffic_descriptor_profiles"

    #id = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r ".items[0].id"'], shell=True)

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"interface\": { \
    \"name\": \"PON port\", \
    \"description\": \"Channel Termination for Freedom Tower\", \
    \"type\": \"channel-termination\", \
    \"enabled\": true, \
    \"link_up_down_trap_enable\": \"TRAP_DISABLED\" \
  }, \
  \"data\": { \
    \"channelpair_ref\": \"PON port\", \
    \"meant_for_type_b_primary_role\": false, \
    \"ngpon2_twdm_admin_label\": 0, \
    \"ngpon2_ptp_admin_label\": 0, \
    \"xgs_ponid\": 0, \
    \"xgpon_ponid\": 0, \
    \"gpon_ponid\": \"\", \
    \"pon_tag\": \"\", \
    \"ber_calc_period\": 0, \
    \"location\": \"AT&T WTC OLT\", \
    \"url_to_reach\": \"\" \
  }, \
  \"name\": \"PON port\" \
}' " + VOLTHA_BASE_URL + "/devices/" + sys.argv[2].rstrip("\n") + "/channel_terminations/PON%20port")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/devices/" + sys.argv[2].rstrip("\n") + "/channel_terminations | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/devices/" + sys.argv[2].rstrip("\n") + "/channel_terminations"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"interface\": { \
    \"name\": \"ATT Golden User\", \
    \"description\": \"ATT Golden User in Freedom Tower\", \
    \"type\": \"v-ontani\", \
    \"enabled\": true, \
    \"link_up_down_trap_enable\": \"TRAP_DISABLED\" \
  }, \
  \"data\": { \
    \"parent_ref\": \"WTC\", \
    \"expected_serial_number\": " + "\"" + sys.argv[3].rstrip("\n") + "\"" + ", \
    \"expected_registration_id\": \"1234567890\", \
    \"preferred_chanpair\": \"PON port\", \
    \"protection_chanpair\": \"\", \
    \"upstream_channel_speed\": 0, \
    \"onu_id\": 4 \
  }, \
  \"name\": \"ATT Golden User\" \
}' " + VOLTHA_BASE_URL + "/v_ont_anis/ATT%20Golden%20User")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/v_ont_anis | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/v_ont_anis"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"interface\": { \
    \"name\": \"ATT Golden User\", \
    \"description\": \"ATT Golden User in Freedom Tower\", \
    \"type\": \"ontani\", \
    \"enabled\": true, \
    \"link_up_down_trap_enable\": \"TRAP_DISABLED\" \
  }, \
  \"data\": { \
    \"upstream_fec_indicator\": true, \
    \"mgnt_gemport_aes_indicator\": false \
  }, \
  \"name\": \"ATT Golden User\" \
}' " + VOLTHA_BASE_URL + "/ont_anis/ATT%20Golden%20User")
    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/ont_anis | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/ont_anis"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"name\": \"TCont 1\", \
  \"interface_reference\": \"ATT Golden User\", \
  \"traffic_descriptor_profile_ref\": \"TDP 1\", \
  \"alloc_id\": 1024 \
}' " + VOLTHA_BASE_URL + "/tconts/TCont%201")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/tconts | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/tconts"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"interface\": { \
  \"name\": \"Enet UNI 1\", \
  \"description\": \"Ethernet port - 1\", \
  \"type\": \"v-enet\", \
  \"enabled\": true, \
  \"link_up_down_trap_enable\": \"TRAP_DISABLED\" \
  }, \
  \"data\": { \
    \"v_ontani_ref\": \"ATT Golden User\" \
  }, \
  \"name\": \"Enet UNI 1\" \
}' " + VOLTHA_BASE_URL + "/v_enets/Enet%20UNI%201")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/v_enets | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/v_enets"

    time.sleep(3)

    ret = os.system("curl " + HTTP_HEADER + " -X POST -d '{ \
  \"name\": \"Gemport 1\", \
  \"itf_ref\": \"Enet UNI 1\", \
  \"traffic_class\": 2, \
  \"aes_indicator\": true, \
  \"tcont_ref\": \"TCont 1\", \
  \"gemport_id\": 1024 \
}' " + VOLTHA_BASE_URL + "/gemports/Gemport%201")

    if ret == 0:
        os.system("curl -s " + OUTPUT + VOLTHA_BASE_URL + "/gemports | jq -r")
    else:
        print "error on " + VOLTHA_BASE_URL + "/gemports"
        sys.exit()

    if get_waiting_olt_onu(1):
        print "ONU configuration is done!!"
    else:
        sys.exit()

elif sys.argv[1] == "flows":
    os.system("ssh-keygen -f \"/home/`whoami`/.ssh/known_hosts\" -R [localhost]:8101")
    os.system("echo flows -s | sshpass -p karaf ssh -o \"StrictHostKeyChecking no\" -p 8101 karaf@" + ENVOY_IP)
elif sys.argv[1] == "ports":
    os.system("ssh-keygen -f \"/home/`whoami`/.ssh/known_hosts\" -R [localhost]:8101")
    os.system("echo ports -s | sshpass -p karaf ssh -o \"StrictHostKeyChecking no\" -p 8101 karaf@" + ENVOY_IP)
elif sys.argv[1] == "add-sub":
    if len(sys.argv) != 3:
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <C-VID>"
        sys.exit()
    OLT_OF_ID = subprocess.check_output([sys.argv[0] + ' flows | grep of: | cut -d, -f1'], shell=True)
    start = OLT_OF_ID.find('o')
    end = OLT_OF_ID.find('"', start)
    #    netcfg_output = subprocess.check_output(['echo netcfg | sshpass -p karaf ssh -o \"StrictHostKeyChecking no\" -p 8101 karaf@' + ENVOY_IP + ' | grep of:'], shell=True)
    #    start = netcfg_output.find('o')
    #    end = netcfg_output.find('"', start)
    #    if len(sys.argv) != 4 or sys.argv[2] == "" or sys.argv[3] == "" or sys.argv[4] == "":
    #       print "Usage: python " + sys.argv[1] + " <port> <Vid>"
    #       sys.exit()
    #    os.system("echo \"add-subscriber-access " + netcfg_output[start:end].rstrip("\n") + " " + sys.argv[2] + " " + sys.argv[3] + \
    #            "\" | sshpass -p karaf ssh -o \"StrictHostKeyChecking no\" -p 8101 karaf@" + ENVOY_IP + " 2>&1 > /dev/null | echo {} > /dev/null")
    os.system("echo \"add-subscriber-access " + OLT_OF_ID[start:end].rstrip("\n") + " " + LOGICAL_PORT + " " + sys.argv[2] + \
             "\" | sshpass -p karaf ssh -o \"StrictHostKeyChecking no\" -p 8101 karaf@" + ENVOY_IP + hidden_log)
elif sys.argv[1] == "all":
    if len(sys.argv) != 4:
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <host:port> <C-VID>"
        sys.exit()
    os.system(sys.argv[0] + " add " + " " + sys.argv[2])

    olt_id = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[0].id'], shell=True)

    print
    for item in [0,1]:
        os.system(sys.argv[0] + " " + method[item] + " " + olt_id.rstrip("\n"))
        time.sleep(5)
    '''
    print
    time.sleep(5)
    for item in [0,1]:
        if method[item] == "enable":
            olt_id = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r .items[' + str(item) + '].id'], shell=True)
            os.system(sys.argv[0] + " " + method[item] + " " + olt_id.rstrip("\n"))
        else:
            os.system(sys.argv[0] + " " + method[item])
        print
        delay_time=time_tick
        while delay_time < max_delay_time:
            print("%s %s, waiting for %d seconds" % (method[item],unit_type[item],delay_time))
            time.sleep(time_tick)
            delay_time += time_tick
            oper_status = subprocess.check_output(['curl -s ' + VOLTHA_BASE_URL + '/devices | jq -r ".items[' + str(item) + '].oper_status"'], shell=True)
            if oper_status.rstrip("\n") == "ACTIVE":
                break
        if delay_time >= max_delay_time:
            print ("Over time for %s %s, quit!!" % (method[item],unit_type[item]))
            sys.exit()
    '''
    time.sleep(5)
    os.system(sys.argv[0] + " add-sub " + sys.argv[3])
elif sys.argv[1] == "aaa":
#    ret = os.system("curl --user karaf:karaf -X POST -H 'Content-Type: application/json'" + " " + ONOS_BASE_URL + "/network/configuration/" + " -d '{\"apps\":{\"org.opencord.aaa\":{\"AAA\": {\"radiusSecret\":\"xxx\",\"radiusIp\":\"172.22.176.118\",\"radiusConnectionType\":\"socket\",\"packetCustomizer\":\"sample\"}}}}'")
    os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X DELETE " + ONOS_BASE_URL + "/applications/org.opencord.aaa/active | jq -r ")
    os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X POST " + ONOS_BASE_URL + "/applications/org.opencord.aaa/active | jq -r ")
      
    ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X POST " + HTTP_HEADER + " " + ONOS_BASE_URL + "/network/configuration" + " -d '{ \
    \"apps\": { \
        \"org.opencord.aaa\": { \
        \"AAA\": { \
            \"radiusIp\": \"192.168.1.128\", \
            \"nasIp\": \"192.168.1.128\", \
            \"nasMac\" : \"00:1b:22:34:55:78\", \
            \"radiusServerPort\": \"1812\", \
            \"radiusSecret\": \"SECRET\", \
            \"radiusMac\" : \"00:1e:67:d2:ee:f7\", \
            \"vlanId\" : \"4000\", \
            \"radiusConnectionType\" : \"socket\", \
            \"radiusServerConnectPoints\": [ \"of:00000000000000b2/2\" ], \
            \"packetCustomizer\" : \"sample\" \
        } \
    }} \
    }'")
    '''
            \"bindings\" : [ \
            { \
                \"mac\" : \"de:ad:be:ef:ba:11\", \
                \"s-tag\" : 10, \
                \"c-tag\" : 20, \
                \"nas_port_id\" : \"location\" \
            }, \
            { \
                \"mac\" : \"de:ad:be:ef:ca:fe\", \
                \"s-tag\" : 10, \
                \"c-tag\" : 20, \
                \"nas_port_id\" : \"location\" \
                sMac" : "00:1b:22:34:55:78",           } ] \
    '''
    if ret == 0:
        ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s " + ONOS_BASE_URL + "/network/configuration/apps/org.opencord.aaa | jq -r")
    else:
        print "error on AAA configurations"

    ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X POST " + HTTP_HEADER + " " + ONOS_BASE_URL + "/network/configuration" + " -d '{ \
    \"apps\": { \
        \"org.opencord.sadis\": { \
        \"sadis\": { \
            \"integration\" : { \
                \"cache\" : { \
                    \"enabled\" : true, \
                    \"maxsize\" : 50, \
                    \"ttl\" : \"PT1m\" \
                } \
            }, \
            \"entries\" : [ { \
                \"id\" : \"uni-128\", \
                \"cTag\" : 2, \
                \"sTag\" : 2, \
                \"nasPortId\" : \"uni-128\" \
            }, { \
                \"id\" : \"1d3eafb52e4e44b08818ab9ebaf7c0d4\", \
                \"hardwareIdentifier\" : \"00:1b:22:00:b1:78\", \
                \"ipAddress\" : \"192.168.1.252\", \
                \"nasId\" : \"B100-NASID\" \
            } ] \
        } \
    }} \
    }'")

    if ret == 0:
        ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s " + ONOS_BASE_URL + "/network/configuration/apps/org.opencord.sadis | jq -r")
    else:
        print "error on SADIS configurations"
elif sys.argv[1] == "dhcp":

    #state = subprocess.check_output(['curl --user ' + KARAF_USER + ':' + KARAF_PASSWORD + ' -s ' + ONOS_BASE_URL + '/network/configuration/apps/org.onosproject.dhcp | jq -r \".code\"'], shell=True)
    #if state.rstrip("\n") == "404":
    os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X DELETE " + ONOS_BASE_URL + "/applications/org.onosproject.dhcp/active | jq -r")
    os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X POST " + ONOS_BASE_URL + "/applications/org.onosproject.dhcp/active | jq -r")

    ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X POST " + HTTP_HEADER + " " + ONOS_BASE_URL + "/network/configuration" + " -d '{ \
    \"apps\": { \
        \"org.onosproject.dhcp\" : { \
            \"dhcp\" : { \
                \"ip\": \"192.168.1.128\", \
                \"mac\": \"ca:fe:ca:fe:ca:fe\", \
                \"subnet\": \"255.255.255.0\", \
                \"broadcast\": \"192.168.1.255\", \
                \"router\": \"192.168.1.128\", \
                \"domain\": \"8.8.8.8\", \
                \"ttl\": \"63\", \
                \"lease\": \"300\", \
                \"renew\": \"150\", \
                \"rebind\": \"200\", \
                \"delay\": \"2\", \
                \"timeout\": \"150\", \
                \"startip\": \"192.168.1.50\", \
                \"endip\": \"192.168.1.200\" \
           } \
       }} \
    }'")


    if ret == 0:
        ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s " + ONOS_BASE_URL + "/network/configuration/apps/org.onosproject.dhcp | jq -r")
    else:
        print "error on DHCP configrations"
elif sys.argv[1] == "uplink":
    if len(sys.argv) != 3:
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <S-VLAN>"
        sys.exit()

    '''
    if not validate_mac(sys.argv[2]):
        print "Please check MAC address"
        sys.exit()

    mac_addr=sys.argv[2].replace(':','').replace('-','')
    '''

    if not sys.argv[2].isdigit():
        print "Please check S-VLAN"
        sys.exit()


    ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s -X POST " + HTTP_HEADER + " " + ONOS_BASE_URL + "/network/configuration" + " -d '{ \
    \"devices\": { \
    \"of:0001000000000001" + "\" : { \
        \"basic\" : { \
            \"driver\": \"pmc-olt\" \
        }, \
        \"accessDevice\": { \
            \"uplink\": \"129\", \
            \"vlan\": \"" + sys.argv[2].rstrip("\n") + "\" \
        } \
    }} \
    }'")
    
    if ret == 0:
        ret = os.system("curl --user " + KARAF_USER + ":" + KARAF_PASSWORD + OUTPUT + " -s " + ONOS_BASE_URL + "/network/configuration/devices/of:0001000000000001 | jq -r")
    else:
        print "error on OLT uplink configurations"

elif sys.argv[1] == "go":
    if len(sys.argv) != 7:
        print "Usage: " + sys.argv[0] + " " + sys.argv[1] + " <OLT MAC> <OLT Listen IP Address> <OLT Listen Port> <S-VLAN> <C-VLAN>"
        sys.exit()

    if not validate_mac(sys.argv[2]):
        print "Please check MAC address"
        sys.exit()

    if not validate_ip(sys.argv[3]):
        print "Please check IP address"
        sys.exit()

    if not sys.argv[5].isdigit():
        print "Please check S-VLAN"
        sys.exit()

    os.system(sys.argv[0] + " uplink " + sys.argv[2] + " " + sys.argv[5] )
    os.system(sys.argv[0] + " aaa")
    os.system(sys.argv[0] + " dhcp")
    os.system(sys.argv[0] + " all" + sys.argv[3] + ":" + sys.argv[4] + " " + sys.argv[6])
else:
    print "Usage: " + sys.argv[0] + CMD_USAGE
    sys.exit()

