## ONOS bring-up

```
docker pull onosproject/onos
docker run -itd --name=onos onosproject/onos
ssh -p 8101 karaf@localhost
```

Loaded olt, config


TODO: 
